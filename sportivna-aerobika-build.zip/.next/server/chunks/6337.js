exports.id=6337,exports.ids=[2377,6337],exports.modules={10317:(e,t,r)=>{"use strict";r.d(t,{Tq:()=>a});let s=new(r(20549)).u(process.env.RESEND_API_KEY),n={roleRequestApproved:e=>({subject:"\uD83C\uDF89 Ваш запит на роль схвалено - ФУСАФ",html:`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Запит схвалено</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; }
          .button { background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 16px 0; }
          .footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎉 Вітаємо, ${e.userName}!</h1>
            <p>Ваш запит на роль схвалено</p>
          </div>
          <div class="content">
            <h2>Деталі схвалення:</h2>
            <p><strong>Запитувана роль:</strong> ${i(e.requestedRole)}</p>
            <p><strong>Схвалено:</strong> ${e.reviewedBy}</p>
            <p><strong>Дата схвалення:</strong> ${new Date().toLocaleDateString("uk-UA")}</p>

            ${e.reviewComment?`
              <div style="background: #e8f5e8; padding: 15px; border-radius: 6px; margin: 16px 0;">
                <h3>💬 Коментар адміністратора:</h3>
                <p>${e.reviewComment}</p>
              </div>
            `:""}

            <p>Тепер ви можете користуватися розширеними можливостями системи ФУСАФ.</p>

            <a href="https://same-eikk4fzfmr5-latest.netlify.app/athlete-panel" class="button">
              Перейти в особистий кабінет
            </a>
          </div>
          <div class="footer">
            <p>З повагою,<br>Команда Федерації України зі Спортивної Аеробіки і Фітнесу</p>
            <p>Email: info@fusaf.org.ua | Сайт: https://same-eikk4fzfmr5-latest.netlify.app</p>
          </div>
        </div>
      </body>
      </html>
    `,text:`
Вітаємо, ${e.userName}!

Ваш запит на роль "${i(e.requestedRole)}" було схвалено.

Деталі:
- Схвалено: ${e.reviewedBy}
- Дата: ${new Date().toLocaleDateString("uk-UA")}
${e.reviewComment?`- Коментар: ${e.reviewComment}`:""}

Тепер ви можете користуватися розширеними можливостями системи ФУСАФ.

Перейти в особистий кабінет: https://same-eikk4fzfmr5-latest.netlify.app/athlete-panel

З повагою,
Команда ФУСАФ
    `}),roleRequestRejected:e=>({subject:"❌ Ваш запит на роль відхилено - ФУСАФ",html:`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Запит відхилено</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; }
          .button { background: #3498db; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 16px 0; }
          .footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${e.userName}</h1>
            <p>Щодо вашого запиту на роль</p>
          </div>
          <div class="content">
            <h2>❌ Запит відхилено</h2>
            <p><strong>Запитувана роль:</strong> ${i(e.requestedRole)}</p>
            <p><strong>Розглянув:</strong> ${e.reviewedBy}</p>
            <p><strong>Дата:</strong> ${new Date().toLocaleDateString("uk-UA")}</p>

            ${e.reviewComment?`
              <div style="background: #ffebee; padding: 15px; border-radius: 6px; margin: 16px 0; border-left: 4px solid #f44336;">
                <h3>💬 Причина відхилення:</h3>
                <p>${e.reviewComment}</p>
              </div>
            `:""}

            <p>Ви можете подати новий запит після усунення зазначених недоліків.</p>

            <a href="https://same-eikk4fzfmr5-latest.netlify.app/athlete-panel" class="button">
              Подати новий запит
            </a>
          </div>
          <div class="footer">
            <p>З повагою,<br>Команда Федерації України зі Спортивної Аеробіки і Фітнесу</p>
            <p>Email: info@fusaf.org.ua | Сайт: https://same-eikk4fzfmr5-latest.netlify.app</p>
          </div>
        </div>
      </body>
      </html>
    `,text:`
${e.userName},

На жаль, ваш запит на роль "${i(e.requestedRole)}" було відхилено.

Деталі:
- Розглянув: ${e.reviewedBy}
- Дата: ${new Date().toLocaleDateString("uk-UA")}
${e.reviewComment?`- Причина: ${e.reviewComment}`:""}

Ви можете подати новий запит після усунення зазначених недоліків.

Подати новий запит: https://same-eikk4fzfmr5-latest.netlify.app/athlete-panel

З повагою,
Команда ФУСАФ
    `})};function i(e){return({athlete:"Спортсмен",club_owner:"Власник клубу",coach_judge:"Тренер/Суддя"})[e]||e}async function a(e,t,r){if(!process.env.RESEND_API_KEY)return console.warn("⚠️ RESEND_API_KEY не налаштований - email не відправлено"),{success:!1,error:"Email service не налаштований"};try{let i="approved"===t?n.roleRequestApproved(r):n.roleRequestRejected(r);console.log(`📧 Відправка email: ${t} для ${e}`);let a=await s.emails.send({from:"ФУСАФ <noreply@fusaf.org.ua>",to:[e],subject:i.subject,html:i.html,text:i.text});return console.log("✅ Email відправлено успішно:",a.data?.id),{success:!0,emailId:a.data?.id}}catch(e){return console.error("❌ Помилка відправки email:",e),{success:!1,error:e instanceof Error?e.message:"Невідома помилка"}}}},12377:(e,t,r)=>{"use strict";r.d(t,{HybridStorage:()=>i});let s=[{id:"1",userEmail:"john.doe@example.com",userName:"Іван Петренко",currentRole:"athlete",requestedRole:"club_owner",reason:"Хочу відкрити власний клуб спортивної аеробіки в Києві. Маю досвід тренування та бажання розвивати цей спорт серед молоді.",status:"pending",requestDate:"2025-01-07T10:30:00.000Z"},{id:"2",userEmail:"coach.maria@example.com",userName:"Марія Коваленко",currentRole:"athlete",requestedRole:"coach_judge",reason:"Маю досвід тренерської роботи 5 років та хочу стати сертифікованим суддею для проведення змагань.",status:"approved",requestDate:"2025-01-05T14:20:00.000Z",reviewedBy:"andfedos@gmail.com",reviewDate:"2025-01-06T09:15:00.000Z",reviewComment:"Схвалено. Досвід підтверджено документами."},{id:"3",userEmail:"trainer.alex@example.com",userName:"Олександр Шевченко",currentRole:"athlete",requestedRole:"coach_judge",reason:"Закінчив спортивний університет, маю кваліфікацію тренера з гімнастики. Хочу розширити свої можливості в аеробіці.",status:"rejected",requestDate:"2025-01-04T16:45:00.000Z",reviewedBy:"andfedos@gmail.com",reviewDate:"2025-01-05T11:30:00.000Z",reviewComment:"Потрібні додаткові документи про кваліфікацію в аеробіці."},{id:"1751971234567",userEmail:"aerobicsua@gmail.com",userName:"Andrii Fedosenko",currentRole:"athlete",requestedRole:"club_owner",reason:"Хочу створити власний клуб спортивної аеробіки для розвитку цього виду спорту в Україні. Маю досвід організації спортивних заходів та роботи з молоддю.",status:"pending",requestDate:"2025-07-08T10:45:00.000Z"}];function n(){global.__FUSAF_HYBRID_STORAGE__||(global.__FUSAF_HYBRID_STORAGE__={requests:[...s],lastUpdate:new Date().toISOString(),instanceId:`instance-${Date.now()}`})}let i={getAll:()=>(n(),[...global.__FUSAF_HYBRID_STORAGE__.requests]),add(e){n();let t=global.__FUSAF_HYBRID_STORAGE__;t.requests.find(t=>t.id===e.id)?console.log("⚠️ HybridStorage.add() - запит вже існує:",e.id):(t.requests.push(e),t.lastUpdate=new Date().toISOString())},update(e,t){n();let r=global.__FUSAF_HYBRID_STORAGE__,s=r.requests.findIndex(t=>t.id===e);return -1===s?(console.log("❌ HybridStorage.update() - запит не знайдено:",e),!1):(r.requests[s]={...r.requests[s],...t},r.lastUpdate=new Date().toISOString(),console.log("✅ HybridStorage.update() оновив запит:",{id:e,status:t.status,instanceId:r.instanceId,lastUpdate:r.lastUpdate}),!0)},findByEmailAndStatus(e,t){n();let r=global.__FUSAF_HYBRID_STORAGE__,s=r.requests.find(r=>r.userEmail===e&&r.status===t);return console.log("\uD83D\uDD0D HybridStorage.findByEmailAndStatus():",{email:e,status:t,found:!!s,instanceId:r.instanceId}),s||null},getStats(){n();let e=global.__FUSAF_HYBRID_STORAGE__,t={total:e.requests.length,pending:e.requests.filter(e=>"pending"===e.status).length,approved:e.requests.filter(e=>"approved"===e.status).length,rejected:e.requests.filter(e=>"rejected"===e.status).length,storageType:"HYBRID_STORAGE",lastUpdate:e.lastUpdate,instanceId:e.instanceId};return console.log("\uD83D\uDCCA HybridStorage.getStats():",t),t},getDebugInfo(){n();let e=global.__FUSAF_HYBRID_STORAGE__;return{message:"\uD83D\uDD25 HYBRID Storage працює",storageType:"HYBRID_STORAGE",compatible:"Netlify serverless with improved sync",explanation:{problem:"Файлова система Netlify read-only, Global object має проблеми синхронізації",solution:"Гібридний підхід з покращеною синхронізацією між функціями",improvement:"Persistent state в memory + кращий lifecycle management"},storage:{totalRequests:e.requests.length,lastUpdate:e.lastUpdate,instanceId:e.instanceId,uptime:Date.now()-Number.parseInt(e.instanceId.split("-")[1])},requests:e.requests.map(e=>({id:e.id,userEmail:e.userEmail,userName:e.userName,requestedRole:e.requestedRole,status:e.status,requestDate:e.requestDate,reason:e.reason.substring(0,50)+"..."}))}}}},20549:(e,t,r)=>{"use strict";r.d(t,{u:()=>R});var s=Object.defineProperty,n=Object.defineProperties,i=Object.getOwnPropertyDescriptors,a=Object.getOwnPropertySymbols,o=Object.prototype.hasOwnProperty,d=Object.prototype.propertyIsEnumerable,l=(e,t,r)=>t in e?s(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,u=(e,t)=>{for(var r in t||(t={}))o.call(t,r)&&l(e,r,t[r]);if(a)for(var r of a(t))d.call(t,r)&&l(e,r,t[r]);return e},c=(e,t)=>n(e,i(t)),h=(e,t,r)=>new Promise((s,n)=>{var i=e=>{try{o(r.next(e))}catch(e){n(e)}},a=e=>{try{o(r.throw(e))}catch(e){n(e)}},o=e=>e.done?s(e.value):Promise.resolve(e.value).then(i,a);o((r=r.apply(e,t)).next())}),p=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return h(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},m=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return h(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return h(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function f(e){return{attachments:e.attachments,bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var g=class{constructor(e){this.resend=e}send(e){return h(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return h(this,arguments,function*(e,t={}){let s=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(1953).then(r.bind(r,81953));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}s.push(f(t))}return yield this.resend.post("/emails/batch",s,t)})}},y=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(1953).then(r.bind(r,81953));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return h(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return h(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return h(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return h(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},b=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return h(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return h(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return h(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return h(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},_=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return h(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return h(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return h(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return h(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},v=class{constructor(e){this.resend=e}send(e){return h(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return h(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(1953).then(r.bind(r,81953));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",f(e),t)})}get(e){return h(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return h(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return h(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},x="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",w="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:4.6.0",R=class{constructor(e){if(this.key=e,this.apiKeys=new p(this),this.audiences=new m(this),this.batch=new g(this),this.broadcasts=new y(this),this.contacts=new b(this),this.domains=new _(this),this.emails=new v(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":w,"Content-Type":"application/json"})}fetchRequest(e){return h(this,arguments,function*(e,t={}){try{let r=yield fetch(`${x}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:c(u({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return h(this,arguments,function*(e,t,r={}){let s=new Headers(this.headers);r.idempotencyKey&&s.set("Idempotency-Key",r.idempotencyKey);let n=u({method:"POST",headers:s,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}get(e){return h(this,arguments,function*(e,t={}){let r=u({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return h(this,arguments,function*(e,t,r={}){let s=u({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,s)})}patch(e,t){return h(this,arguments,function*(e,t,r={}){let s=u({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,s)})}delete(e,t){return h(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}}},78335:()=>{},96487:()=>{}};