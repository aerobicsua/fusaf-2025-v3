exports.id=7555,exports.ids=[7555],exports.modules={20549:(e,t,r)=>{"use strict";r.d(t,{u:()=>E});var i=Object.defineProperty,n=Object.defineProperties,s=Object.getOwnPropertyDescriptors,a=Object.getOwnPropertySymbols,o=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,d=(e,t,r)=>t in e?i(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,c=(e,t)=>{for(var r in t||(t={}))o.call(t,r)&&d(e,r,t[r]);if(a)for(var r of a(t))l.call(t,r)&&d(e,r,t[r]);return e},u=(e,t)=>n(e,s(t)),p=(e,t,r)=>new Promise((i,n)=>{var s=e=>{try{o(r.next(e))}catch(e){n(e)}},a=e=>{try{o(r.throw(e))}catch(e){n(e)}},o=e=>e.done?i(e.value):Promise.resolve(e.value).then(s,a);o((r=r.apply(e,t)).next())}),h=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return p(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},m=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return p(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return p(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function g(e){return{attachments:e.attachments,bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var y=class{constructor(e){this.resend=e}send(e){return p(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return p(this,arguments,function*(e,t={}){let i=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(1953).then(r.bind(r,81953));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}i.push(g(t))}return yield this.resend.post("/emails/batch",i,t)})}},f=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(1953).then(r.bind(r,81953));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return p(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return p(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return p(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return p(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},x=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return p(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return p(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return p(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return p(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},b=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return p(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return p(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return p(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return p(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},v=class{constructor(e){this.resend=e}send(e){return p(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return p(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(1953).then(r.bind(r,81953));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",g(e),t)})}get(e){return p(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return p(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return p(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},$="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",w="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:4.6.0",E=class{constructor(e){if(this.key=e,this.apiKeys=new h(this),this.audiences=new m(this),this.batch=new y(this),this.broadcasts=new f(this),this.contacts=new x(this),this.domains=new b(this),this.emails=new v(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":w,"Content-Type":"application/json"})}fetchRequest(e){return p(this,arguments,function*(e,t={}){try{let r=yield fetch(`${$}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:u(c({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return p(this,arguments,function*(e,t,r={}){let i=new Headers(this.headers);r.idempotencyKey&&i.set("Idempotency-Key",r.idempotencyKey);let n=c({method:"POST",headers:i,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}get(e){return p(this,arguments,function*(e,t={}){let r=c({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return p(this,arguments,function*(e,t,r={}){let i=c({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,i)})}patch(e,t){return p(this,arguments,function*(e,t,r={}){let i=c({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,i)})}delete(e,t){return p(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}}},21111:(e,t,r)=>{"use strict";r.d(t,{Z$:()=>n,_N:()=>o,zs:()=>l});let i=new(r(20549)).u(process.env.RESEND_API_KEY);var n=function(e){return e.WELCOME="welcome",e.REGISTRATION_CONFIRMATION="registration_confirmation",e.PAYMENT_SUCCESS="payment_success",e.COMPETITION_REMINDER="competition_reminder",e.NEWSLETTER="newsletter",e.PASSWORD_RESET="password_reset",e.CLUB_INVITE="club_invite",e}({});let s={welcome:e=>({subject:`Ласкаво просимо до ФУСАФ, ${e.name}!`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #3B82F6, #EC4899); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">🇺🇦 ФУСАФ</h1>
          <p style="color: white; margin: 10px 0 0 0;">Федерація України зі Спортивної Аеробіки і Фітнесу</p>
        </div>

        <div style="padding: 30px; background: white;">
          <h2 style="color: #1F2937;">Вітаємо, ${e.name}!</h2>

          <p>Дякуємо за реєстрацію в ФУСАФ як <strong>${"athlete"===e.role?"спортсмен":"coach"===e.role?"тренер":"judge"===e.role?"суддя":"власник клубу"}</strong>.</p>

          <div style="background: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #374151;">Ваші наступні кроки:</h3>
            <ul style="color: #6B7280;">
              <li>Заповніть свій профіль повністю</li>
              <li>Приєднайтеся до клубу або створіть власний</li>
              <li>Зареєструйтеся на найближчі змагання</li>
              <li>Ознайомтеся з правилами та інструкціями</li>
            </ul>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${e.dashboardUrl}" style="background: #3B82F6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Перейти до особистого кабінету
            </a>
          </div>

          <p style="color: #6B7280; font-size: 14px;">
            Якщо у вас виникли питання, зверніться до нас:
            <a href="mailto:info@fusaf.org.ua">info@fusaf.org.ua</a>
          </p>
        </div>

        <div style="background: #F9FAFB; padding: 20px; text-align: center; color: #6B7280; font-size: 12px;">
          \xa9 2025 Федерація України зі Спортивної Аеробіки і Фітнесу<br>
          <a href="${e.unsubscribeUrl}">Відписатися від розсилки</a>
        </div>
      </div>
    `,text:`Ласкаво просимо до ФУСАФ, ${e.name}!

Дякуємо за реєстрацію як ${e.role}.

Ваші наступні кроки:
- Заповніть свій профіль повністю
- Приєднайтеся до клубу або створіть власний
- Зареєструйтеся на найближчі змагання
- Ознайомтеся з правилами та інструкціями

Перейти до кабінету: ${e.dashboardUrl}

З питаннями звертайтеся: info@fusaf.org.ua

\xa9 2025 ФУСАФ`}),registration_confirmation:e=>({subject:`Підтвердження реєстрації на змагання "${e.competitionTitle}"`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #10B981, #3B82F6); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">🏆 Реєстрацію підтверджено!</h1>
        </div>

        <div style="padding: 30px; background: white;">
          <h2 style="color: #1F2937;">Вітаємо, ${e.participantName}!</h2>

          <p>Ваша реєстрація на змагання успішно підтверджена.</p>

          <div style="background: #F0FDF4; border-left: 4px solid #10B981; padding: 20px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #065F46;">Деталі змагання:</h3>
            <p><strong>Назва:</strong> ${e.competitionTitle}</p>
            <p><strong>Дата:</strong> ${e.competitionDate}</p>
            <p><strong>Час:</strong> ${e.competitionTime}</p>
            <p><strong>Місце:</strong> ${e.location}</p>
            <p><strong>Адреса:</strong> ${e.address}</p>
            <p><strong>Категорія:</strong> ${e.category}</p>
            <p><strong>Вікова група:</strong> ${e.ageGroup}</p>
          </div>

          <div style="background: #FEF3C7; border-left: 4px solid #F59E0B; padding: 20px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #92400E;">Важлива інформація:</h3>
            <ul style="color: #78350F; margin: 0;">
              <li>Прибудьте за 1 годину до початку змагань</li>
              <li>Не забудьте медичну довідку</li>
              <li>Форма має відповідати правилам федерації</li>
              <li>Контактна особа: ${e.contactPerson}</li>
            </ul>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${e.competitionUrl}" style="background: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin-right: 10px;">
              Деталі змагання
            </a>
            <a href="${e.dashboardUrl}" style="background: #6B7280; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Мої реєстрації
            </a>
          </div>
        </div>
      </div>
    `,text:`Підтвердження реєстрації на змагання "${e.competitionTitle}"

Вітаємо, ${e.participantName}!

Деталі змагання:
- Назва: ${e.competitionTitle}
- Дата: ${e.competitionDate}
- Час: ${e.competitionTime}
- Місце: ${e.location}
- Категорія: ${e.category}

Прибудьте за 1 годину до початку. Не забудьте медичну довідку.

Деталі: ${e.competitionUrl}`}),payment_success:e=>({subject:`Оплата підтверджена - ${e.competitionTitle}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #059669, #0D9488); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">💳 Оплата успішна!</h1>
        </div>

        <div style="padding: 30px; background: white;">
          <h2 style="color: #1F2937;">Дякуємо за оплату, ${e.participantName}!</h2>

          <div style="background: #ECFDF5; border: 1px solid #10B981; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #065F46;">✅ Платіж успішно оброблено</h3>
            <p><strong>Сума:</strong> ${e.amount} грн</p>
            <p><strong>Номер транзакції:</strong> ${e.transactionId}</p>
            <p><strong>Дата платежу:</strong> ${e.paymentDate}</p>
          </div>

          <p>Ваша участь у змаганні <strong>"${e.competitionTitle}"</strong> повністю підтверджена.</p>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${e.receiptUrl}" style="background: #059669; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Завантажити квитанцію
            </a>
          </div>
        </div>
      </div>
    `,text:`Оплата підтверджена - ${e.competitionTitle}

Дякуємо за оплату, ${e.participantName}!

Платіж успішно оброблено:
- Сума: ${e.amount} грн
- Транзакція: ${e.transactionId}
- Дата: ${e.paymentDate}

Ваша участь підтверджена.`}),competition_reminder:e=>({subject:`Нагадування: змагання "${e.competitionTitle}" завтра!`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #F59E0B, #EF4444); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">⏰ Нагадування про змагання</h1>
        </div>

        <div style="padding: 30px; background: white;">
          <h2 style="color: #1F2937;">Готуйтеся до змагань, ${e.participantName}!</h2>

          <div style="background: #FEF3C7; border-left: 4px solid #F59E0B; padding: 20px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #92400E;">Змагання завтра:</h3>
            <p><strong>${e.competitionTitle}</strong></p>
            <p>📅 ${e.competitionDate}</p>
            <p>🕐 ${e.competitionTime}</p>
            <p>📍 ${e.location}</p>
          </div>

          <h3 style="color: #374151;">Checklist перед змаганнями:</h3>
          <ul style="color: #6B7280;">
            <li>✅ Медична довідка (обов'язково!)</li>
            <li>✅ Спортивна форма відповідно до правил</li>
            <li>✅ Документ, що посвідчує особу</li>
            <li>✅ Питна вода та перекус</li>
            <li>✅ Прибуття за 1 годину до початку</li>
          </ul>

          <div style="background: #EFF6FF; border-left: 4px solid #3B82F6; padding: 20px; margin: 20px 0;">
            <p style="margin: 0; color: #1E40AF;">
              <strong>Контакти організаторів:</strong><br>
              📞 ${e.organizerPhone}<br>
              📧 ${e.organizerEmail}
            </p>
          </div>
        </div>
      </div>
    `,text:`Нагадування: змагання "${e.competitionTitle}" завтра!

Готуйтеся, ${e.participantName}!

Змагання завтра:
- ${e.competitionTitle}
- ${e.competitionDate} о ${e.competitionTime}
- ${e.location}

Не забудьте:
- Медичну довідку
- Спортивну форму
- Документ особи
- Прибути за годину

Контакти: ${e.organizerPhone}, ${e.organizerEmail}`}),newsletter:e=>({subject:`📰 Новини ФУСАФ - ${e.title}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #6366F1, #8B5CF6); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">📰 Новини ФУСАФ</h1>
          <p style="color: white; margin: 10px 0 0 0;">${e.title}</p>
        </div>

        <div style="padding: 30px; background: white;">
          ${e.content}

          <div style="text-align: center; margin: 30px 0;">
            <a href="${e.readMoreUrl}" style="background: #6366F1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Читати повністю
            </a>
          </div>
        </div>

        <div style="background: #F9FAFB; padding: 20px; text-align: center; color: #6B7280; font-size: 12px;">
          <a href="${e.unsubscribeUrl}">Відписатися від новин</a>
        </div>
      </div>
    `,text:`Новини ФУСАФ - ${e.title}

${e.textContent}

Читати повністю: ${e.readMoreUrl}

Відписатися: ${e.unsubscribeUrl}`}),password_reset:e=>({subject:"Скидання паролю ФУСАФ",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #EF4444, #F97316); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">🔐 Скидання паролю</h1>
        </div>

        <div style="padding: 30px; background: white;">
          <h2 style="color: #1F2937;">Вітаємо, ${e.name}!</h2>

          <p>Ви запросили скидання паролю для вашого акаунту ФУСАФ.</p>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${e.resetUrl}" style="background: #EF4444; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Скинути пароль
            </a>
          </div>

          <p style="color: #6B7280; font-size: 14px;">
            Посилання дійсне протягом 1 години. Якщо ви не запросили скидання паролю, проігноруйте цей лист.
          </p>
        </div>
      </div>
    `,text:`Скидання паролю ФУСАФ

Вітаємо, ${e.name}!

Для скидання паролю перейдіть за посиланням: ${e.resetUrl}

Посилання дійсне 1 годину.`}),club_invite:e=>({subject:`Запрошення до клубу "${e.clubName}"`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #8B5CF6, #EC4899); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">🏢 Запрошення до клубу</h1>
        </div>

        <div style="padding: 30px; background: white;">
          <h2 style="color: #1F2937;">Вас запросили до клубу!</h2>

          <p><strong>${e.inviterName}</strong> запросив вас приєднатися до клубу <strong>"${e.clubName}"</strong>.</p>

          <div style="background: #F5F3FF; border-left: 4px solid #8B5CF6; padding: 20px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #5B21B6;">Про клуб:</h3>
            <p><strong>Назва:</strong> ${e.clubName}</p>
            <p><strong>Місто:</strong> ${e.clubCity}</p>
            <p><strong>Опис:</strong> ${e.clubDescription}</p>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${e.acceptUrl}" style="background: #8B5CF6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin-right: 10px;">
              Прийняти запрошення
            </a>
            <a href="${e.declineUrl}" style="background: #6B7280; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Відхилити
            </a>
          </div>
        </div>
      </div>
    `,text:`Запрошення до клубу "${e.clubName}"

${e.inviterName} запросив вас приєднатися до клубу "${e.clubName}" у місті ${e.clubCity}.

Про клуб: ${e.clubDescription}

Прийняти: ${e.acceptUrl}
Відхилити: ${e.declineUrl}`})};async function a({to:e,type:t,data:r,attachments:n}){try{let a=s[t](r),o=await i.emails.send({from:`ФУСАФ <${process.env.FROM_EMAIL||"noreply@fusaf.org.ua"}>`,to:Array.isArray(e)?e:[e],subject:a.subject,html:a.html,text:a.text,attachments:n||[]});if(o.error)return console.error("Email send error:",o.error),{success:!1,error:o.error.message};return console.log("Email sent successfully:",o.data?.id),{success:!0,messageId:o.data?.id}}catch(e){return console.error("Email service error:",e),{success:!1,error:e instanceof Error?e.message:"Unknown error"}}}let o={sendEmail:a,sendWelcomeEmail:async(e,t)=>a({to:e,type:"welcome",data:t}),sendRegistrationConfirmation:async(e,t)=>a({to:e,type:"registration_confirmation",data:t}),sendPaymentSuccess:async(e,t)=>a({to:e,type:"payment_success",data:t}),sendCompetitionReminder:async(e,t)=>a({to:e,type:"competition_reminder",data:t}),sendNewsletter:async(e,t)=>a({to:e,type:"newsletter",data:t}),sendBulkEmails:async e=>{let t=await Promise.allSettled(e.map(e=>a({to:e.to,type:e.type,data:e.data}))),r=t.filter(e=>"fulfilled"===e.status&&e.value.success).length,i=t.length-r;return{total:t.length,successful:r,failed:i,results:t}}};function l(e){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)}},78335:()=>{},96487:()=>{}};