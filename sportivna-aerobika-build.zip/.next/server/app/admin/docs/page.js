(()=>{var e={};e.id=4004,e.ids=[4004],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},13904:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>p,pages:()=>d,routeModule:()=>h,tree:()=>c});var s=r(65239),i=r(48088),n=r(88170),o=r.n(n),l=r(30893),a={};for(let e in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(a[e]=()=>l[e]);r.d(t,a);let c={children:["",{children:["admin",{children:["docs",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,24112)),"/home/project/sportivna-aerobika/src/app/admin/docs/page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,94431)),"/home/project/sportivna-aerobika/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"]}]}.children,d=["/home/project/sportivna-aerobika/src/app/admin/docs/page.tsx"],p={require:r,loadChunk:()=>Promise.resolve()},h=new s.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/admin/docs/page",pathname:"/admin/docs",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},24112:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s});let s=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/project/sportivna-aerobika/src/app/admin/docs/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/project/sportivna-aerobika/src/app/admin/docs/page.tsx","default")},27247:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(82614).A)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},36558:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(82614).A)("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]])},44184:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>v});var s=r(76392),i=r(76180),n=r.n(i),o=r(43210),l=r(12566),a=r(44493),c=r(82614);let d=(0,c.A)("Book",[["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",key:"k3hazp"}]]);var p=r(48206),h=r(53098),u=r(36558),m=r(27247),g=r(81801),f=r(53597),x=r(58369),y=r(74158);let b=(0,c.A)("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]),_=[{id:"overview",title:"Огляд системи",icon:d,content:`
      <h3>Про систему ФУСАФ</h3>
      <p>Сайт ФУСАФ - це повноцінна платформа для управління Федерацією України зі Спортивної Аеробіки і Фітнесу.</p>

      <h4>Основні функції:</h4>
      <ul>
        <li>Система реєстрації користувачів (спортсмени, тренери, судді, власники клубів)</li>
        <li>Управління змаганнями та реєстраціями</li>
        <li>Платіжна система LiqPay</li>
        <li>Email розсилки та сповіщення</li>
        <li>Аналітика та звітність</li>
        <li>Резервне копіювання та безпека</li>
      </ul>

      <h4>Технічний стек:</h4>
      <ul>
        <li><strong>Frontend:</strong> Next.js 15 + TypeScript + Tailwind CSS + shadcn/ui</li>
        <li><strong>Backend:</strong> Next.js API Routes</li>
        <li><strong>Database:</strong> Supabase (PostgreSQL)</li>
        <li><strong>Authentication:</strong> NextAuth.js + Google OAuth</li>
        <li><strong>Email:</strong> Resend API</li>
        <li><strong>Payments:</strong> LiqPay</li>
        <li><strong>Hosting:</strong> ADM.tools (Node.js)</li>
      </ul>
    `},{id:"users",title:"Управління користувачами",icon:p.A,content:`
      <h3>Ролі користувачів</h3>
      <ul>
        <li><strong>athlete</strong> - спортсмен</li>
        <li><strong>coach</strong> - тренер</li>
        <li><strong>judge</strong> - суддя</li>
        <li><strong>club_owner</strong> - власник клубу</li>
      </ul>

      <h3>Операції з користувачами</h3>

      <h4>Перегляд користувачів</h4>
      <p>Для перегляду всіх користувачів використовуйте SQL запит:</p>
      <pre><code>SELECT * FROM users ORDER BY created_at DESC;</code></pre>

      <p>Користувачі за роллю:</p>
      <pre><code>SELECT * FROM users WHERE role = 'athlete';</code></pre>

      <h4>Видалення користувача</h4>
      <div class="warning">
        <strong>⚠️ УВАГА:</strong> Видалення користувача також видаляє всі пов'язані дані!
      </div>

      <p>Перед видаленням перевірте залежності:</p>
      <pre><code>SELECT
  (SELECT COUNT(*) FROM registrations WHERE user_id = 'USER_ID') as registrations,
  (SELECT COUNT(*) FROM clubs WHERE owner_id = 'USER_ID') as owned_clubs;</code></pre>
    `},{id:"competitions",title:"Управління змаганнями",icon:h.A,content:`
      <h3>Статуси змагань</h3>
      <ul>
        <li><strong>draft</strong> - чернетка</li>
        <li><strong>published</strong> - опубліковано</li>
        <li><strong>registration_open</strong> - відкрита реєстрація</li>
        <li><strong>registration_closed</strong> - реєстрація закрита</li>
        <li><strong>in_progress</strong> - проходить</li>
        <li><strong>completed</strong> - завершено</li>
        <li><strong>cancelled</strong> - скасовано</li>
      </ul>

      <h3>Створення змагання через API</h3>
      <pre><code>POST /api/competitions
{
  "title": "Кубок України 2025",
  "description": "Національні змагання",
  "date": "2025-03-15",
  "time": "10:00",
  "location": "Палац спорту Україна",
  "registration_fee": 500,
  "max_participants": 150,
  "age_groups": ["8-10", "11-13", "14-16"],
  "categories": ["індивідуальна", "пара"],
  "status": "published"
}</code></pre>

      <h3>Статуси реєстрацій</h3>
      <ul>
        <li><strong>pending</strong> - очікує підтвердження</li>
        <li><strong>confirmed</strong> - підтверджено</li>
        <li><strong>cancelled</strong> - скасовано</li>
        <li><strong>waitlist</strong> - список очікування</li>
      </ul>
    `},{id:"payments",title:"Платіжна система",icon:u.A,content:`
      <h3>Налаштування LiqPay</h3>

      <h4>Environment Variables</h4>
      <pre><code>LIQPAY_PUBLIC_KEY=your_public_key
LIQPAY_PRIVATE_KEY=your_private_key
LIQPAY_SANDBOX=false  # true для тестування</code></pre>

      <h3>Процес платежу</h3>
      <ol>
        <li>Користувач реєструється на змагання</li>
        <li>Система генерує платіжну форму LiqPay</li>
        <li>Користувач сплачує</li>
        <li>LiqPay відправляє callback на <code>/api/payments/liqpay/callback</code></li>
        <li>Система оновлює статус платежу</li>
        <li>Відправляється email підтвердження</li>
      </ol>

      <h3>Статуси платежів</h3>
      <ul>
        <li><strong>pending</strong> - очікує оплати</li>
        <li><strong>paid</strong> - оплачено</li>
        <li><strong>failed</strong> - помилка оплати</li>
        <li><strong>refunded</strong> - повернено</li>
      </ul>

      <h3>Тестування платежів</h3>
      <p>Для тестування в LiqPay Sandbox використовуйте:</p>
      <pre><code>Номер карти: 4000000000000002
Дата: 12/25
CVV: 123</code></pre>
    `},{id:"email",title:"Email система",icon:m.A,content:`
      <h3>Налаштування Resend</h3>

      <h4>Environment Variables</h4>
      <pre><code>RESEND_API_KEY=your_resend_api_key
FROM_EMAIL=noreply@fusaf.org.ua</code></pre>

      <h3>Типи email повідомлень</h3>
      <ul>
        <li><strong>WELCOME</strong> - привітання нових користувачів</li>
        <li><strong>REGISTRATION_CONFIRMATION</strong> - підтвердження реєстрації</li>
        <li><strong>PAYMENT_SUCCESS</strong> - успішна оплата</li>
        <li><strong>COMPETITION_REMINDER</strong> - нагадування про змагання</li>
        <li><strong>NEWSLETTER</strong> - новини та оголошення</li>
        <li><strong>PASSWORD_RESET</strong> - скидання паролю</li>
        <li><strong>CLUB_INVITE</strong> - запрошення до клубу</li>
      </ul>

      <h3>Відправка email через API</h3>
      <pre><code>POST /api/emails/send
{
  "to": "user@example.com",
  "type": "WELCOME",
  "data": {
    "name": "Іван Петренко",
    "role": "athlete",
    "dashboardUrl": "https://fusaf.org.ua/dashboard"
  }
}</code></pre>

      <h3>Масова розсилка</h3>
      <p>Для відправки новин всім користувачам певної ролі:</p>
      <pre><code>const athletes = await getUserEmailsByRole('athlete');
await EmailService.sendNewsletter(athletes, newsletterData);</code></pre>
    `},{id:"analytics",title:"Аналітика та звіти",icon:g.A,content:`
      <h3>Доступні звіти</h3>

      <h4>Статистика користувачів</h4>
      <pre><code>GET /api/analytics?type=users&period=month</code></pre>
      <p>Повертає: загальна кількість, нові користувачі, активні, розподіл за ролями</p>

      <h4>Статистика змагань</h4>
      <pre><code>GET /api/analytics?type=competitions&period=month</code></pre>
      <p>Повертає: кількість змагань, реєстрації, популярні категорії</p>

      <h4>Фінансова статистика</h4>
      <pre><code>GET /api/analytics?type=financial&period=month</code></pre>
      <p>Повертає: загальний дохід, успішні платежі, дохід по місяцях</p>

      <h3>Експорт звітів</h3>
      <pre><code>GET /api/analytics?type=full&format=csv
GET /api/analytics?type=full&format=pdf</code></pre>

      <h3>Автоматичні звіти</h3>
      <pre><code>POST /api/analytics/reports
{
  "reportType": "weekly",
  "emails": ["admin@fusaf.org.ua"],
  "schedule": "0 9 * * 1"  // Щопонеділка о 9:00
}</code></pre>
    `},{id:"backup",title:"Резервне копіювання",icon:g.A,content:`
      <h3>Автоматичне резервне копіювання</h3>

      <h4>Створення резервної копії</h4>
      <pre><code>POST /api/backup
{
  "type": "full"  // full або incremental
}</code></pre>

      <h4>Список резервних копій</h4>
      <pre><code>GET /api/backup</code></pre>

      <h4>Відновлення з резервної копії</h4>
      <div class="warning">
        <strong>⚠️ УВАГА:</strong> Відновлення перезапише існуючі дані!
      </div>
      <pre><code>POST /api/backup/restore
{
  "backupId": "backup_1234567890_abc123"
}</code></pre>

      <h3>Ручне резервне копіювання</h3>
      <p>Експорт важливих таблиць через SQL:</p>
      <pre><code>\\copy users TO 'users_backup.csv' CSV HEADER;
\\copy competitions TO 'competitions_backup.csv' CSV HEADER;
\\copy registrations TO 'registrations_backup.csv' CSV HEADER;</code></pre>

      <h3>Налаштування автоматичного резервного копіювання</h3>
      <pre><code>const backupConfig = {
  frequency: 'daily',      // daily, weekly, monthly
  retentionDays: 30,       // зберігати 30 днів
  includeFiles: true,
  compression: true,
  encryption: true
};</code></pre>
    `},{id:"security",title:"Безпека",icon:f.A,content:`
      <h3>Системні логи</h3>

      <h4>Категорії логів</h4>
      <ul>
        <li><strong>auth</strong> - аутентифікація та авторизація</li>
        <li><strong>database</strong> - операції з базою даних</li>
        <li><strong>api</strong> - API запити</li>
        <li><strong>backup</strong> - резервне копіювання</li>
        <li><strong>system</strong> - системні події</li>
      </ul>

      <h4>Рівні важливості</h4>
      <ul>
        <li><strong>info</strong> - інформаційні повідомлення</li>
        <li><strong>warning</strong> - попередження</li>
        <li><strong>error</strong> - помилки</li>
        <li><strong>critical</strong> - критичні події</li>
      </ul>

      <h3>Перегляд логів</h3>
      <pre><code>-- Останні критичні події
SELECT * FROM security_logs
WHERE level = 'critical'
ORDER BY timestamp DESC
LIMIT 50;

-- Події аутентифікації за останню добу
SELECT * FROM security_logs
WHERE category = 'auth'
AND timestamp > NOW() - INTERVAL '1 day'
ORDER BY timestamp DESC;</code></pre>

      <h3>Моніторинг здоров'я системи</h3>
      <pre><code>GET /api/analytics?type=health</code></pre>
      <p>Повертає статус бази даних, email сервісу, аутентифікації та час відповіді</p>
    `},{id:"maintenance",title:"Технічне обслуговування",icon:x.A,content:`
      <h3>Щоденні завдання</h3>
      <ul>
        <li>Перевірити статус системи</li>
        <li>Переглянути критичні логи</li>
        <li>Перевірити стан резервних копій</li>
        <li>Перевірити email доставку</li>
      </ul>

      <h3>Тижневі завдання</h3>
      <ul>
        <li>Аналіз статистики користувачів</li>
        <li>Перевірка безпеки (підозріла активність)</li>
        <li>Очистка старих логів</li>
        <li>Перевірка продуктивності</li>
      </ul>

      <h3>Місячні завдання</h3>
      <ul>
        <li>Повний звіт аналітики</li>
        <li>Аудит безпеки</li>
        <li>Оновлення документації</li>
        <li>Планування розвитку</li>
      </ul>

      <h3>Оновлення системи</h3>

      <h4>Оновлення залежностей</h4>
      <pre><code># Перевірка оновлень
bun outdated

# Оновлення залежностей
bun update

# Тестування після оновлення
bun test
bun build</code></pre>

      <h3>Типові проблеми</h3>

      <h4>Сайт не відкривається</h4>
      <ol>
        <li>Перевірити статус Node.js додатку в ADM.tools</li>
        <li>Перевірити логи сервера</li>
        <li>Перевірити DNS записи</li>
        <li>Перевірити SSL сертифікат</li>
      </ol>

      <h4>Помилки аутентифікації</h4>
      <ol>
        <li>Перевірити Google OAuth налаштування</li>
        <li>Перевірити Supabase URL та ключі</li>
        <li>Перевірити NEXTAUTH_URL в environment variables</li>
      </ol>
    `}];function v(){let[e,t]=(0,o.useState)("overview"),r=_.find(t=>t.id===e);return(0,s.jsxs)("div",{className:"jsx-8f15cd2149c0cb04 min-h-screen bg-gray-50",children:[(0,s.jsx)(l.Y,{}),(0,s.jsxs)("div",{className:"jsx-8f15cd2149c0cb04 container mx-auto px-4 py-8",children:[(0,s.jsxs)("div",{className:"jsx-8f15cd2149c0cb04 mb-8",children:[(0,s.jsx)("h1",{className:"jsx-8f15cd2149c0cb04 text-3xl font-bold text-gray-900 mb-2",children:"\uD83D\uDCDA Документація адміністратора ФУСАФ"}),(0,s.jsx)("p",{className:"jsx-8f15cd2149c0cb04 text-gray-600",children:"Повний посібник з управління системою"})]}),(0,s.jsxs)("div",{className:"jsx-8f15cd2149c0cb04 grid grid-cols-1 lg:grid-cols-4 gap-8",children:[(0,s.jsx)("div",{className:"jsx-8f15cd2149c0cb04 lg:col-span-1",children:(0,s.jsxs)(a.Zp,{className:"sticky top-4",children:[(0,s.jsx)(a.aR,{children:(0,s.jsx)(a.ZB,{className:"text-lg",children:"Розділи"})}),(0,s.jsx)(a.Wu,{className:"p-0",children:(0,s.jsx)("nav",{className:"jsx-8f15cd2149c0cb04 space-y-1",children:_.map(r=>{let i=r.icon;return(0,s.jsxs)("button",{onClick:()=>t(r.id),className:`jsx-8f15cd2149c0cb04 w-full flex items-center space-x-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors ${e===r.id?"bg-blue-50 border-r-2 border-blue-500 text-blue-700":"text-gray-700"}`,children:[(0,s.jsx)(i,{className:"jsx-8f15cd2149c0cb04 h-4 w-4"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04 text-sm font-medium",children:r.title}),e===r.id&&(0,s.jsx)(y.A,{className:"h-4 w-4 ml-auto"})]},r.id)})})})]})}),(0,s.jsxs)("div",{className:"jsx-8f15cd2149c0cb04 lg:col-span-3",children:[(0,s.jsxs)(a.Zp,{children:[(0,s.jsx)(a.aR,{children:(0,s.jsxs)(a.ZB,{className:"flex items-center space-x-2",children:[r&&(0,s.jsx)(r.icon,{className:"h-6 w-6"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04",children:r?.title})]})}),(0,s.jsx)(a.Wu,{children:(0,s.jsx)("div",{dangerouslySetInnerHTML:{__html:r?.content||""},style:{fontSize:"14px",lineHeight:"1.6"},className:"jsx-8f15cd2149c0cb04 prose prose-gray max-w-none"})})]}),(0,s.jsxs)(a.Zp,{className:"mt-6",children:[(0,s.jsx)(a.aR,{children:(0,s.jsxs)(a.ZB,{className:"flex items-center space-x-2",children:[(0,s.jsx)(b,{className:"h-5 w-5"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04",children:"Корисні посилання"})]})}),(0,s.jsx)(a.Wu,{children:(0,s.jsxs)("div",{className:"jsx-8f15cd2149c0cb04 grid grid-cols-2 md:grid-cols-4 gap-4",children:[(0,s.jsxs)("a",{href:"https://nextjs.org/docs",target:"_blank",rel:"noopener noreferrer",className:"jsx-8f15cd2149c0cb04 flex items-center space-x-2 text-blue-600 hover:text-blue-800 text-sm",children:[(0,s.jsx)(b,{className:"h-4 w-4"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04",children:"Next.js Docs"})]}),(0,s.jsxs)("a",{href:"https://supabase.com/docs",target:"_blank",rel:"noopener noreferrer",className:"jsx-8f15cd2149c0cb04 flex items-center space-x-2 text-blue-600 hover:text-blue-800 text-sm",children:[(0,s.jsx)(b,{className:"h-4 w-4"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04",children:"Supabase Docs"})]}),(0,s.jsxs)("a",{href:"https://resend.com/docs",target:"_blank",rel:"noopener noreferrer",className:"jsx-8f15cd2149c0cb04 flex items-center space-x-2 text-blue-600 hover:text-blue-800 text-sm",children:[(0,s.jsx)(b,{className:"h-4 w-4"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04",children:"Resend Docs"})]}),(0,s.jsxs)("a",{href:"https://www.liqpay.ua/documentation",target:"_blank",rel:"noopener noreferrer",className:"jsx-8f15cd2149c0cb04 flex items-center space-x-2 text-blue-600 hover:text-blue-800 text-sm",children:[(0,s.jsx)(b,{className:"h-4 w-4"}),(0,s.jsx)("span",{className:"jsx-8f15cd2149c0cb04",children:"LiqPay Docs"})]})]})})]})]})]})]}),(0,s.jsx)(n(),{id:"8f15cd2149c0cb04",children:'.prose h3{font-size:1.25rem;font-weight:600;margin-top:2rem;margin-bottom:1rem;color:#1f2937}.prose h4{font-size:1.1rem;font-weight:600;margin-top:1.5rem;margin-bottom:.75rem;color:#374151}.prose ul,.prose ol{margin:1rem 0;padding-left:1.5rem}.prose li{margin:.5rem 0}.prose pre{background:#f9fafb;border:1px solid#e5e7eb;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;padding:1rem;overflow-x:auto;margin:1rem 0}.prose code{background:#f3f4f6;padding:.2rem .4rem;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;font-size:.875rem;font-family:"Monaco","Menlo","Ubuntu Mono",monospace}.prose pre code{background:none;padding:0}.prose .warning{background:#fef3c7;border:1px solid#f59e0b;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;padding:1rem;margin:1rem 0}.prose p{margin:.75rem 0;color:#4b5563}'})]})}},48206:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(82614).A)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},53098:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(82614).A)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},53597:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(82614).A)("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]])},56397:()=>{},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},75913:(e,t,r)=>{"use strict";r(56397);var s=r(43210),i=function(e){return e&&"object"==typeof e&&"default"in e?e:{default:e}}(s),n="undefined"!=typeof process&&process.env&&!0,o=function(e){return"[object String]"===Object.prototype.toString.call(e)},l=function(){function e(e){var t=void 0===e?{}:e,r=t.name,s=void 0===r?"stylesheet":r,i=t.optimizeForSpeed,l=void 0===i?n:i;a(o(s),"`name` must be a string"),this._name=s,this._deletedRulePlaceholder="#"+s+"-deleted-rule____{}",a("boolean"==typeof l,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=l,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0,this._nonce=null}var t,r=e.prototype;return r.setOptimizeForSpeed=function(e){a("boolean"==typeof e,"`setOptimizeForSpeed` accepts a boolean"),a(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=e,this.inject()},r.isOptimizeForSpeed=function(){return this._optimizeForSpeed},r.inject=function(){var e=this;a(!this._injected,"sheet already injected"),this._injected=!0,this._serverSheet={cssRules:[],insertRule:function(t,r){return"number"==typeof r?e._serverSheet.cssRules[r]={cssText:t}:e._serverSheet.cssRules.push({cssText:t}),r},deleteRule:function(t){e._serverSheet.cssRules[t]=null}}},r.getSheetForTag=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]},r.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},r.insertRule=function(e,t){return a(o(e),"`insertRule` accepts only strings"),"number"!=typeof t&&(t=this._serverSheet.cssRules.length),this._serverSheet.insertRule(e,t),this._rulesCount++},r.replaceRule=function(e,t){this._optimizeForSpeed;var r=this._serverSheet;if(t.trim()||(t=this._deletedRulePlaceholder),!r.cssRules[e])return e;r.deleteRule(e);try{r.insertRule(t,e)}catch(s){n||console.warn("StyleSheet: illegal rule: \n\n"+t+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),r.insertRule(this._deletedRulePlaceholder,e)}return e},r.deleteRule=function(e){this._serverSheet.deleteRule(e)},r.flush=function(){this._injected=!1,this._rulesCount=0,this._serverSheet.cssRules=[]},r.cssRules=function(){return this._serverSheet.cssRules},r.makeStyleTag=function(e,t,r){t&&a(o(t),"makeStyleTag accepts only strings as second parameter");var s=document.createElement("style");this._nonce&&s.setAttribute("nonce",this._nonce),s.type="text/css",s.setAttribute("data-"+e,""),t&&s.appendChild(document.createTextNode(t));var i=document.head||document.getElementsByTagName("head")[0];return r?i.insertBefore(s,r):i.appendChild(s),s},t=[{key:"length",get:function(){return this._rulesCount}}],function(e,t){for(var r=0;r<t.length;r++){var s=t[r];s.enumerable=s.enumerable||!1,s.configurable=!0,"value"in s&&(s.writable=!0),Object.defineProperty(e,s.key,s)}}(e.prototype,t),e}();function a(e,t){if(!e)throw Error("StyleSheet: "+t+".")}var c=function(e){for(var t=5381,r=e.length;r;)t=33*t^e.charCodeAt(--r);return t>>>0},d={};function p(e,t){if(!t)return"jsx-"+e;var r=String(t),s=e+r;return d[s]||(d[s]="jsx-"+c(e+"-"+r)),d[s]}function h(e,t){var r=e+(t=t.replace(/\/style/gi,"\\/style"));return d[r]||(d[r]=t.replace(/__jsx-style-dynamic-selector/g,e)),d[r]}var u=function(){function e(e){var t=void 0===e?{}:e,r=t.styleSheet,s=void 0===r?null:r,i=t.optimizeForSpeed,n=void 0!==i&&i;this._sheet=s||new l({name:"styled-jsx",optimizeForSpeed:n}),this._sheet.inject(),s&&"boolean"==typeof n&&(this._sheet.setOptimizeForSpeed(n),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var t=e.prototype;return t.add=function(e){var t=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(e.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed());var r=this.getIdAndRules(e),s=r.styleId,i=r.rules;if(s in this._instancesCounts){this._instancesCounts[s]+=1;return}var n=i.map(function(e){return t._sheet.insertRule(e)}).filter(function(e){return -1!==e});this._indices[s]=n,this._instancesCounts[s]=1},t.remove=function(e){var t=this,r=this.getIdAndRules(e).styleId;if(function(e,t){if(!e)throw Error("StyleSheetRegistry: "+t+".")}(r in this._instancesCounts,"styleId: `"+r+"` not found"),this._instancesCounts[r]-=1,this._instancesCounts[r]<1){var s=this._fromServer&&this._fromServer[r];s?(s.parentNode.removeChild(s),delete this._fromServer[r]):(this._indices[r].forEach(function(e){return t._sheet.deleteRule(e)}),delete this._indices[r]),delete this._instancesCounts[r]}},t.update=function(e,t){this.add(t),this.remove(e)},t.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},t.cssRules=function(){var e=this,t=this._fromServer?Object.keys(this._fromServer).map(function(t){return[t,e._fromServer[t]]}):[],r=this._sheet.cssRules();return t.concat(Object.keys(this._indices).map(function(t){return[t,e._indices[t].map(function(e){return r[e].cssText}).join(e._optimizeForSpeed?"":"\n")]}).filter(function(e){return!!e[1]}))},t.styles=function(e){var t,r;return t=this.cssRules(),void 0===(r=e)&&(r={}),t.map(function(e){var t=e[0],s=e[1];return i.default.createElement("style",{id:"__"+t,key:"__"+t,nonce:r.nonce?r.nonce:void 0,dangerouslySetInnerHTML:{__html:s}})})},t.getIdAndRules=function(e){var t=e.children,r=e.dynamic,s=e.id;if(r){var i=p(s,r);return{styleId:i,rules:Array.isArray(t)?t.map(function(e){return h(i,e)}):[h(i,t)]}}return{styleId:p(s),rules:Array.isArray(t)?t:[t]}},t.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e,t){return e[t.id.slice(2)]=t,e},{})},e}(),m=s.createContext(null);m.displayName="StyleSheetContext";i.default.useInsertionEffect||i.default.useLayoutEffect;var g=void 0;function f(e){var t=g||s.useContext(m);return t&&t.add(e),null}f.dynamic=function(e){return e.map(function(e){return p(e[0],e[1])}).join(" ")},t.style=f},76180:(e,t,r)=>{"use strict";e.exports=r(75913).style},81801:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(82614).A)("Database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]])},81968:(e,t,r)=>{Promise.resolve().then(r.bind(r,24112))},91696:(e,t,r)=>{Promise.resolve().then(r.bind(r,44184))}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4243,1947,5772,8036],()=>r(13904));module.exports=s})();