(()=>{var e={};e.id=6480,e.ids=[6480],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3662:(e,s,r)=>{"use strict";r.d(s,{A:()=>t});let t=(0,r(82614).A)("CircleCheckBig",[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]])},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11997:e=>{"use strict";e.exports=require("punycode")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},23860:(e,s,r)=>{"use strict";r.r(s),r.d(s,{GlobalError:()=>l.a,__next_app__:()=>u,pages:()=>d,routeModule:()=>p,tree:()=>o});var t=r(65239),a=r(48088),i=r(88170),l=r.n(i),c=r(30893),n={};for(let e in c)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>c[e]);r.d(s,n);let o={children:["",{children:["test-db",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,44994)),"/home/project/sportivna-aerobika/src/app/test-db/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,94431)),"/home/project/sportivna-aerobika/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"]}]}.children,d=["/home/project/sportivna-aerobika/src/app/test-db/page.tsx"],u={require:r,loadChunk:()=>Promise.resolve()},p=new t.AppPageRouteModule({definition:{kind:a.RouteKind.APP_PAGE,page:"/test-db/page",pathname:"/test-db",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:o}})},27910:e=>{"use strict";e.exports=require("stream")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},39727:()=>{},44994:(e,s,r)=>{"use strict";r.r(s),r.d(s,{default:()=>t});let t=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/project/sportivna-aerobika/src/app/test-db/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/project/sportivna-aerobika/src/app/test-db/page.tsx","default")},47990:()=>{},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},72963:(e,s,r)=>{"use strict";r.d(s,{A:()=>t});let t=(0,r(82614).A)("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},73698:(e,s,r)=>{Promise.resolve().then(r.bind(r,44994))},74075:e=>{"use strict";e.exports=require("zlib")},77368:(e,s,r)=>{"use strict";r.d(s,{A:()=>t});let t=(0,r(82614).A)("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]])},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},81801:(e,s,r)=>{"use strict";r.d(s,{A:()=>t});let t=(0,r(82614).A)("Database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]])},84220:(e,s,r)=>{"use strict";r.r(s),r.d(s,{default:()=>A});var t=r(76392),a=r(43210),i=r(12566),l=r(29523),c=r(44493),n=r(96834),o=r(5745),d=r(60463);let u=(0,o.createClientComponentClient)();(0,d.UU)("https://wmdkymgpcitlnfiwmsuq.supabase.co",process.env.SUPABASE_SERVICE_ROLE_KEY);let p="https://wmdkymgpcitlnfiwmsuq.supabase.co",m="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndtZGt5bWdwY2l0bG5maXdtc3VxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU5OTk4MjksImV4cCI6MjA1MTU3NTgyOX0.FuBl5OIHTKDhqhOlHYMdDZ_jJOMNRXVnlSpPbp4L02o",E=(0,d.UU)(p,m);async function h(){try{console.log("\uD83D\uDD17 Testing Supabase connection..."),console.log("URL:",p),console.log("Key:",m.substring(0,20)+"...");let{data:e,error:s}=await E.from("users").select("count").limit(1);if(s)return console.error("❌ Supabase connection failed:",s.message),s.message.includes('relation "public.users" does not exist')&&console.log("\uD83D\uDCA1 Database schema needs to be created!"),{success:!1,error:s.message};return console.log("✅ Supabase connection successful!"),{success:!0}}catch(e){return console.error("❌ Unexpected error:",e),{success:!1,error:String(e)}}}var x=r(81801),T=r(77368);let N=(0,r(82614).A)("Play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]);var b=r(3662),j=r(97025),g=r(72963);function A(){let[e,s]=(0,a.useState)(null),[r,o]=(0,a.useState)(!1),[d,p]=(0,a.useState)(null),[m,E]=(0,a.useState)(!1),A=async()=>{o(!0),s(null);try{let e=await h();s(e)}catch(e){s({success:!1,error:String(e)})}finally{o(!1)}},y=async()=>{E(!0),p(null);try{console.log("\uD83D\uDE80 Creating database schema...");let e=`
        -- Enable UUID extension
        CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

        -- Create custom types
        DO $$ BEGIN
            CREATE TYPE user_role AS ENUM ('athlete', 'club_owner', 'coach_judge', 'admin');
        EXCEPTION
            WHEN duplicate_object THEN null;
        END $$;

        DO $$ BEGIN
            CREATE TYPE sport_level AS ENUM ('beginner', 'amateur', 'professional', 'elite');
        EXCEPTION
            WHEN duplicate_object THEN null;
        END $$;

        DO $$ BEGIN
            CREATE TYPE competition_category AS ENUM ('open', 'junior', 'senior', 'professional', 'amateur');
        EXCEPTION
            WHEN duplicate_object THEN null;
        END $$;

        DO $$ BEGIN
            CREATE TYPE competition_status AS ENUM ('draft', 'published', 'registration_open', 'registration_closed', 'completed', 'cancelled');
        EXCEPTION
            WHEN duplicate_object THEN null;
        END $$;

        DO $$ BEGIN
            CREATE TYPE registration_status AS ENUM ('pending', 'confirmed', 'cancelled', 'waitlist');
        EXCEPTION
            WHEN duplicate_object THEN null;
        END $$;

        -- Users table (extends Supabase auth.users)
        CREATE TABLE IF NOT EXISTS public.users (
            id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            avatar_url TEXT,
            role user_role NOT NULL DEFAULT 'athlete',
            phone TEXT,
            date_of_birth DATE,
            city TEXT,
            bio TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Enable RLS
        ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

        -- Clubs table
        CREATE TABLE IF NOT EXISTS public.clubs (
            id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            city TEXT NOT NULL,
            address TEXT,
            phone TEXT,
            email TEXT,
            website TEXT,
            owner_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
            logo_url TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Enable RLS
        ALTER TABLE public.clubs ENABLE ROW LEVEL SECURITY;

        -- Competitions table
        CREATE TABLE IF NOT EXISTS public.competitions (
            id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT,
            date DATE NOT NULL,
            time TIME NOT NULL,
            location TEXT NOT NULL,
            address TEXT NOT NULL,
            max_participants INTEGER,
            entry_fee DECIMAL(10,2),
            category competition_category NOT NULL,
            prizes TEXT,
            rules TEXT,
            contact_info TEXT,
            status competition_status NOT NULL DEFAULT 'draft',
            club_id UUID REFERENCES public.clubs(id) ON DELETE CASCADE NOT NULL,
            created_by UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Enable RLS
        ALTER TABLE public.competitions ENABLE ROW LEVEL SECURITY;
      `,{data:s,error:r}=await u.rpc("exec_sql",{sql:e});if(r){console.log("Trying direct table creation...");let{error:e}=await u.from("users").select("count").limit(1);e&&e.message.includes("does not exist")?p({success:!1,error:"Schema creation requires manual setup in Supabase SQL Editor",needsManualSetup:!0}):p({success:!0,message:"Schema appears to be set up correctly"})}else p({success:!0,data:s})}catch(e){console.error("Schema creation error:",e),p({success:!1,error:String(e),needsManualSetup:!0})}finally{E(!1)}},L=async()=>{let e={};for(let s of["users","clubs","competitions","registrations","athlete_profiles","coach_profiles"])try{let{error:r}=await u.from(s).select("count").limit(1);e[s]=!r}catch{e[s]=!1}return e},[S,f]=(0,a.useState)(null),[_,v]=(0,a.useState)(!1),C=async()=>{v(!0);try{let e=await L();f(e)}catch(e){console.error("Error checking tables:",e)}finally{v(!1)}};return(0,t.jsxs)("div",{className:"min-h-screen bg-gray-50",children:[(0,t.jsx)(i.Y,{}),(0,t.jsxs)("div",{className:"container mx-auto px-4 py-8",children:[(0,t.jsxs)("div",{className:"mb-8",children:[(0,t.jsx)("h1",{className:"text-3xl font-bold text-gray-900 mb-2",children:"\uD83D\uDD2C Тестування бази даних"}),(0,t.jsx)("p",{className:"text-gray-600",children:"Перевірка підключення до Supabase та налаштування схеми"})]}),(0,t.jsxs)("div",{className:"grid lg:grid-cols-2 gap-6",children:[(0,t.jsxs)(c.Zp,{children:[(0,t.jsxs)(c.aR,{children:[(0,t.jsxs)(c.ZB,{className:"flex items-center",children:[(0,t.jsx)(x.A,{className:"h-5 w-5 mr-2"}),"Підключення до Supabase"]}),(0,t.jsx)(c.BT,{children:"Перевірка з'єднання з базою даних"})]}),(0,t.jsxs)(c.Wu,{className:"space-y-4",children:[(0,t.jsx)("div",{className:"flex space-x-2",children:(0,t.jsx)(l.$,{onClick:A,disabled:r,className:"btn-aerobics-primary",children:r?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(T.A,{className:"h-4 w-4 mr-2 animate-spin"}),"Тестування..."]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(N,{className:"h-4 w-4 mr-2"}),"Тест підключення"]})})}),e&&(0,t.jsx)("div",{className:`p-4 rounded-lg ${e.success?"bg-green-50 border border-green-200":"bg-red-50 border border-red-200"}`,children:(0,t.jsxs)("div",{className:"flex items-start space-x-2",children:[e.success?(0,t.jsx)(b.A,{className:"h-5 w-5 text-green-500 mt-0.5"}):(0,t.jsx)(j.A,{className:"h-5 w-5 text-red-500 mt-0.5"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:`font-medium ${e.success?"text-green-800":"text-red-800"}`,children:e.success?"Підключення успішне!":"Помилка підключення"}),e.error&&(0,t.jsx)("p",{className:"text-sm text-red-700 mt-1",children:e.error})]})]})})]})]}),(0,t.jsxs)(c.Zp,{children:[(0,t.jsxs)(c.aR,{children:[(0,t.jsxs)(c.ZB,{className:"flex items-center",children:[(0,t.jsx)(x.A,{className:"h-5 w-5 mr-2"}),"Створення схеми"]}),(0,t.jsx)(c.BT,{children:"Налаштування таблиць та структури бази даних"})]}),(0,t.jsxs)(c.Wu,{className:"space-y-4",children:[(0,t.jsx)("div",{className:"flex space-x-2",children:(0,t.jsx)(l.$,{onClick:y,disabled:m,variant:"outline",children:m?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(T.A,{className:"h-4 w-4 mr-2 animate-spin"}),"Створення..."]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(x.A,{className:"h-4 w-4 mr-2"}),"Створити схему"]})})}),d&&(0,t.jsx)("div",{className:`p-4 rounded-lg ${d.success?"bg-green-50 border border-green-200":"bg-yellow-50 border border-yellow-200"}`,children:(0,t.jsxs)("div",{className:"flex items-start space-x-2",children:[d.success?(0,t.jsx)(b.A,{className:"h-5 w-5 text-green-500 mt-0.5"}):(0,t.jsx)(g.A,{className:"h-5 w-5 text-yellow-500 mt-0.5"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:`font-medium ${d.success?"text-green-800":"text-yellow-800"}`,children:d.success?"Схема створена!":"Потрібне ручне налаштування"}),d.error&&(0,t.jsx)("p",{className:"text-sm text-yellow-700 mt-1",children:d.error}),d.needsManualSetup&&(0,t.jsxs)("div",{className:"mt-2 text-sm text-yellow-700",children:[(0,t.jsx)("p",{children:"Для створення схеми:"}),(0,t.jsxs)("ol",{className:"list-decimal list-inside mt-1 space-y-1",children:[(0,t.jsx)("li",{children:"Перейдіть у Supabase Dashboard"}),(0,t.jsx)("li",{children:"Відкрийте SQL Editor"}),(0,t.jsx)("li",{children:"Скопіюйте вміст файлу database/schema.sql"}),(0,t.jsx)("li",{children:"Виконайте SQL команди"})]})]})]})]})})]})]}),(0,t.jsxs)(c.Zp,{className:"lg:col-span-2",children:[(0,t.jsxs)(c.aR,{children:[(0,t.jsxs)(c.ZB,{className:"flex items-center",children:[(0,t.jsx)(b.A,{className:"h-5 w-5 mr-2"}),"Статус таблиць"]}),(0,t.jsx)(c.BT,{children:"Перевірка існування необхідних таблиць"})]}),(0,t.jsxs)(c.Wu,{className:"space-y-4",children:[(0,t.jsx)(l.$,{onClick:C,disabled:_,variant:"outline",children:_?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(T.A,{className:"h-4 w-4 mr-2 animate-spin"}),"Перевірка..."]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(b.A,{className:"h-4 w-4 mr-2"}),"Перевірити таблиці"]})}),S&&(0,t.jsx)("div",{className:"grid md:grid-cols-3 gap-4",children:Object.entries(S).map(([e,s])=>(0,t.jsxs)("div",{className:"flex items-center justify-between p-3 border rounded-lg",children:[(0,t.jsx)("span",{className:"font-medium",children:e}),(0,t.jsx)(n.E,{variant:s?"default":"destructive",children:s?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(b.A,{className:"h-3 w-3 mr-1"}),"Існує"]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(j.A,{className:"h-3 w-3 mr-1"}),"Відсутня"]})})]},e))})]})]})]}),(0,t.jsxs)(c.Zp,{className:"mt-8",children:[(0,t.jsx)(c.aR,{children:(0,t.jsx)(c.ZB,{children:"\uD83D\uDCCB Інструкції з налаштування"})}),(0,t.jsx)(c.Wu,{children:(0,t.jsxs)("div",{className:"prose prose-sm max-w-none",children:[(0,t.jsx)("h4",{children:"1. Налаштування Google OAuth в Supabase:"}),(0,t.jsxs)("ol",{children:[(0,t.jsx)("li",{children:"Перейдіть у Supabase Dashboard → Authentication → Providers"}),(0,t.jsx)("li",{children:"Увімкніть Google Provider"}),(0,t.jsxs)("li",{children:["Додайте redirect URLs: ",(0,t.jsx)("code",{children:"http://localhost:3000/auth/callback"})]})]}),(0,t.jsx)("h4",{children:"2. Створення Google OAuth App:"}),(0,t.jsxs)("ol",{children:[(0,t.jsx)("li",{children:"Перейдіть у Google Cloud Console"}),(0,t.jsx)("li",{children:"Створіть OAuth 2.0 Client ID"}),(0,t.jsxs)("li",{children:["Додайте redirect URI: ",(0,t.jsx)("code",{children:"https://wmdkymgpcitlnfiwmsuq.supabase.co/auth/v1/callback"})]}),(0,t.jsx)("li",{children:"Скопіюйте Client ID та Secret у .env.local"})]}),(0,t.jsx)("h4",{children:"3. Оновлення .env.local:"}),(0,t.jsx)("pre",{className:"bg-gray-100 p-2 rounded",children:`GOOGLE_CLIENT_ID=your_client_id_here
GOOGLE_CLIENT_SECRET=your_client_secret_here`})]})})]})]})]})}},91645:e=>{"use strict";e.exports=require("net")},91850:(e,s,r)=>{Promise.resolve().then(r.bind(r,84220))},94735:e=>{"use strict";e.exports=require("events")},97025:(e,s,r)=>{"use strict";r.d(s,{A:()=>t});let t=(0,r(82614).A)("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]])}};var s=require("../../webpack-runtime.js");s.C(e);var r=e=>s(s.s=e),t=s.X(0,[4243,1947,5772,5745,8036],()=>r(23860));module.exports=t})();