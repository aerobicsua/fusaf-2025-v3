# 🇺🇦 Сайт Федерації України зі Спортивної Аеробіки і Фітнесу (ФУСАФ)

Офіційний сайт ФУСАФ - професійна платформа для управління членством, змаганнями та навчанням з спортивної аеробіки в Україні.

## ✨ Функціональність

- 🏠 **Головна сторінка** з українським дизайном та брендингом ФУСАФ
- 🔐 **Google OAuth аутентифікація** через Supabase
- 👥 **Система ролей**: спортсмен, тренер/суддя, власник клубу
- 🏆 **Управління змаганнями** з календарем та реєстрацією
- 💳 **Платіжна система LiqPay** для оплати участі
- 📚 **Розділи**: членство, курси, новини, клуби, інструкції
- 📊 **Персональні dashboard** для кожної ролі
- 🎨 **Українська локалізація** та символіка

## 🚀 Швидкий деплоймент на ADM.tools

### Крок 1: Завантажте код
```bash
git clone https://github.com/ваш-username/fusaf-website.git
cd fusaf-website
```

### Крок 2: Встановіть залежності
```bash
npm install
# або
bun install
```

### Крок 3: Налаштуйте Environment Variables
Скопіюйте `.env.example` в `.env` та оновіть значення:
```bash
cp .env.example .env
```

### Крок 4: Зберіть проект
```bash
npm run build
# або
bun run build
```

### Крок 5: Запустіть на сервері
```bash
npm start
# або
bun start
```

## 🔧 Налаштування для fusaf.org.ua

### Google OAuth
1. Відкрийте [Google Cloud Console](https://console.cloud.google.com)
2. Створіть або відкрийте OAuth 2.0 Client ID
3. Додайте до **Authorized JavaScript origins**:
   - `https://fusaf.org.ua`
4. Додайте до **Authorized redirect URIs**:
   - `https://fusaf.org.ua/api/auth/callback/google`

### Supabase
1. Відкрийте [Supabase Dashboard](https://supabase.com/dashboard)
2. Перейдіть до Authentication > URL Configuration
3. Встановіть:
   - **Site URL**: `https://fusaf.org.ua`
   - **Redirect URLs**: `https://fusaf.org.ua/auth/callback`

### База даних
Виконайте SQL скрипти з папки `.same/` для створення таблиць та тестових даних.

## 📁 Структура проекту

```
fusaf-website/
├── src/
│   ├── app/                 # Next.js App Router сторінки
│   ├── components/          # React компоненти
│   ├── lib/                 # Утиліти та конфігурації
│   └── ...
├── public/                  # Статичні файли
├── .env.example            # Приклад environment variables
├── package.json            # Залежності проекту
├── next.config.js          # Конфігурація Next.js
└── README.md               # Ця документація
```

## 🛠 Технології

- **Framework**: Next.js 15 (App Router)
- **Styling**: Tailwind CSS + shadcn/ui
- **Database**: Supabase (PostgreSQL)
- **Authentication**: NextAuth.js + Google OAuth
- **Payments**: LiqPay (український платіжний сервіс)
- **Language**: TypeScript
- **Deployment**: ADM.tools (Node.js хостинг)

## 🔐 Environment Variables

Скопіюйте `.env.example` в `.env` та заповніть:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Google OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret

# NextAuth
NEXTAUTH_URL=https://fusaf.org.ua
NEXTAUTH_SECRET=your_secret_key

# App
APP_URL=https://fusaf.org.ua
APP_NAME=ФУСАФ
```

## 📞 Підтримка

Для технічної підтримки:
- 📧 Email: tech@fusaf.org.ua
- 🌐 Сайт: https://fusaf.org.ua

## 📄 Ліцензія

© 2025 Федерація України зі Спортивної Аеробіки і Фітнесу. Всі права захищені.

---

**Розроблено з ❤️ для української спортивної спільноти**
